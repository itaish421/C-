﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced2
{
    public class DigitalBook : Book
    {
        public DigitalBook(string id, string title, string author, string genre) : base(id, title, author, genre)
        {

        }

        public override string ToString()
        {
            return _title + "," + _author + ",digital book";
        }
    }
}
