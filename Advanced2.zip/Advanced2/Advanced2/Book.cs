﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced2
{
    public class Book
    {
        protected string _id;
        protected string _title;
        protected string _author;
        protected string _genre;

        public Book(string id, string title, string author, string genre)
        {
            _id = id;
            _title = title;
            _author = author;
            _genre = genre;
        }

        public string getTitle()
        {
            return _title;
        }

        public string getAuthor()
        {
            return _author;
        }

        public string getGenre()
        {
            return _genre;
        }

        public string getId()
        {
            return _id;
        }
    }

}
