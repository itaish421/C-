﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced2
{

    enum Cases { AddBook = 1, AddSub = 2, Borrowing = 3, ReturnBook = 4, PrintBookDetails = 5, PrintBookGenre = 6, ShowSubBooks = 7, Exit = 8 }

    internal class Program
    {
        static public void Main(string[] args)
        {
            Library library = new Library();
            while (true)
            {
                Console.WriteLine("Welcome to the official library!");
                Console.WriteLine("To add a new book, please press 1.");
                Console.WriteLine("To add a new subscriber, please press 2.");
                Console.WriteLine("To loan a book to subscriber, please press 3.");
                Console.WriteLine("To return the book from the subscriber, please press 4.");
                Console.WriteLine("To print book's details, please press 5.");
                Console.WriteLine("To print the books from specific genre, please press 6.");
                Console.WriteLine("To print books by sub id, please press 7.");
                Console.WriteLine("To exit, press 8.");
                string sifria = Console.ReadLine();
                Cases c;
                if (!Enum.TryParse(sifria, out c))
                {
                    Console.WriteLine("enter a number between 1 and 8");
                    continue;
                }
                switch (c)
                {
                    case Cases.AddBook: library.addBook(); break;
                    case Cases.AddSub: library.addSub(); break;
                    case Cases.Borrowing: library.borrowing(); break;
                    case Cases.ReturnBook: library.returnBook(); break;
                    case Cases.PrintBookDetails: library.printBookDetails(); break;
                    case Cases.PrintBookGenre: library.printBookGenre(); break;
                    case Cases.ShowSubBooks: library.showSubBooks(); break;
                    case Cases.Exit: Console.WriteLine("Good bye!"); break;
                    default: Console.WriteLine("Wrong input. Type a number between 1 and 8."); break;
                }
                if (sifria == "8")
                {
                    break;
                }
            }
        }
    }
}
