﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced2
{
    public class PaperBook : Book
    {
        protected int _copies;

        public PaperBook(string id, string title, string author, string genre, int copies) : base(id, title, author, genre)
        {
            _copies = copies;
        }


        public int getCopies()
        {
            return _copies;
        }
        public void addCopy()
        {
            _copies--;
        }
        public void removeCopy()
        {
            _copies++;
        }
        public bool avilablePaperBook()
        {
            if (_copies > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            return _title + "," + _author + "," + _copies + ",number of avilable copies";
        }
    }
}
