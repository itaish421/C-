﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced2
{
    public class Subscriber
    {
        private string _id;
        private string _firstName;
        private string _lastName;
        Book[] _LoanedBooksArr;

        public Subscriber(string id, string firstname, string lastname)
        {
            _id = id;
            _firstName = firstname;
            _lastName = lastname;
            _LoanedBooksArr = new Book[3];
        }


        public string getFirstName()
        {
            return _firstName;
        }

        public string getLastName()
        {
            return _lastName;
        }

        public void addLoanBook(Book loaned)
        {
            for (int i = 0; i < _LoanedBooksArr.Length; i++)
            {
                if (_LoanedBooksArr[i] == null)
                {
                    _LoanedBooksArr[i] = loaned;
                }
            }

            if (!avilableBookToLoan())
            {
                Console.WriteLine("subscriber reached limit");
            }
        }

        public void returnBookFromLoan(Book book)
        {
            int i;
            for (i = 0; i < _LoanedBooksArr.Length; i++)
            {
                if (_LoanedBooksArr[i].getTitle() == book.getTitle() && _LoanedBooksArr[i].getAuthor() == book.getAuthor())
                {
                    _LoanedBooksArr[i] = null;
                    return;
                }
            }
            Console.WriteLine("The Book was not loaned");
        }

        public bool isBookInSubscriber(Book book)
        {
            for (int i = 0; i < _LoanedBooksArr.Length; i++)
            {
                if (_LoanedBooksArr[i].getTitle() == book.getTitle() && _LoanedBooksArr[i].getAuthor() == book.getAuthor())
                {
                    return true;
                }
            }
            return false;
        }

        public bool avilableBookToLoan()
        {
            for (int i = 0; i < _LoanedBooksArr.Length; i++)
            {
                if (_LoanedBooksArr[i] == null)
                {
                    return true;
                }
            }
            return false;
        }

        public void printBookDetails()
        {
            int books_count = 0;
            for (int i = 0; i < _LoanedBooksArr.Length; i++)
            {
                if (_LoanedBooksArr[i] != null)
                {
                    Console.WriteLine(_LoanedBooksArr[i].ToString());
                    books_count += 1;
                }
            }

            if (books_count == 0)
            {
                Console.WriteLine("the subscriber does not have any books");
            }
        }
    }
}
