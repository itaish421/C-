﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Advanced2
{
    public class Library
    {
        private Dictionary<string, Book> _booksDict;
        private Dictionary<string, Subscriber> _subsDict;

        public Library()
        {
            _booksDict = new Dictionary<string, Book>();
            _subsDict = new Dictionary<string, Subscriber>();
        }
        // public Book searchBook(string title)
        //{
        //Dictionary <string,Book>.ValueCollection values= _booksDict.values;
        //title= ".*" + title + ".*";
        //}
        public void addBook()
        {
            // getting book id
            Console.WriteLine("please enter id");
            string id = Console.ReadLine();
            int int_id;
            if (!int.TryParse(id, out int_id))
            {
                Console.WriteLine("id should be a number with 1 to 5 digits");
                return;
            }

            if (!(int_id > 0 && int_id < 100000))
            {
                Console.WriteLine("id should be a number with 1 to 5 digits");
                return;
            }

            // getting book data
            Console.WriteLine("Please enter title, author and genre");
            string title = Console.ReadLine();
            string author = Console.ReadLine();
            string genre = Console.ReadLine();
            Book book;

            // handling type
            Console.WriteLine("What is the type of the book? DigitalBook or PaperBook?");
            string type = Console.ReadLine();
            if (type == "DigitalBook")
            {
                book = new DigitalBook(id, title, author, genre);
            }
            else if (type == "PaperBook")
            {
                Console.WriteLine("Please enter the copies:");
                string copies_str = Console.ReadLine();
                int copies;
                if (!int.TryParse(copies_str, out copies))
                {
                    Console.WriteLine("number of copies should be a number");
                    return;
                }
                book = new PaperBook(id, title, author, genre, copies);

            }
            else
            {
                Console.WriteLine("Wrong input");
                return;
            }

            Book foundBook = findBook(id);
            if (foundBook == null)
            {
                _booksDict[id] = book;
                return;
            }

            // adding book to the library
            if (foundBook is DigitalBook)
            {
                Console.WriteLine("The book is already exist");
            }
            if (foundBook is PaperBook)
            {
                PaperBook book1_paper = foundBook as PaperBook;
                book1_paper.removeCopy();
                Console.WriteLine("Added Copy");
            }
            return;
        }

        public void addSub()
        {
            // getting subscriber id
            Console.WriteLine("please enter id");
            string id = Console.ReadLine();
            int int_id;
            if (!int.TryParse(id, out int_id))
            {
                Console.WriteLine("id should be a number with 9 digits");
                return;
            }

            if (id.Length != 9)
            {
                Console.WriteLine("id should be a number with 9 digits");
                return;
            }

            if (!(int_id > 0 && int_id < 1000000000))
            {
                Console.WriteLine("id should be a number with 9 digits");
                return;
            }

            Console.WriteLine("Please enter the first and the last name of the subscriber:");
            string firstName = Console.ReadLine();
            string lastName = Console.ReadLine();

            Subscriber sub = new Subscriber(id, firstName, lastName);

            if (findSubscriber(id) == null)
            {
                _subsDict[id] = sub;
                Console.WriteLine("success");
                return;
            }

            Console.WriteLine("The subscriber is already exist");
        }

        public Subscriber findSubscriber(string id)
        {
            if (_subsDict.ContainsKey(id))
            {
                return _subsDict[id];
            }
            return null;
        }

        public Book findBook(string id)
        {
            if (_booksDict.ContainsKey(id))
            {
                return _booksDict[id];
            }
            return null;
        }

        public void borrowing()
        {
            Console.WriteLine("Please enter the id of the loaner:");
            string sub_id = Console.ReadLine();

            Console.Write("would you like to get the book by id or name?");
            string choice = Console.ReadLine();

            Book book;
            if (choice == "name")
            {
                Console.WriteLine("Please enter the book's name");
                string book_name = Console.ReadLine(); // Harry Poter

                int counter = 0;
                Dictionary<string, Book> sameNameDict = new Dictionary<string, Book>();
                foreach (KeyValuePair<string, Book> id_and_book in _booksDict)
                {
                    if (id_and_book.Value.getTitle() == book_name)
                    {
                        counter += 1;
                        sameNameDict.Add(id_and_book.Key, id_and_book.Value);
                    }
                }

                if (counter == 0)
                {
                    Console.WriteLine("book does not exist");
                    return;
                }
                else if (counter == 1)
                {
                    book = sameNameDict.First().Value;
                }
                else
                {
                    foreach (KeyValuePair<string, Book> id_and_book in sameNameDict)
                    {
                        if (id_and_book.Value.getTitle() == book_name)
                        {
                            Console.WriteLine("id: " + id_and_book.Key + ", book: " + id_and_book.Value.ToString());
                        }
                    }
                    Console.WriteLine("choose one of the books by id: ");
                    string chosen_id = Console.ReadLine();
                    if (sameNameDict.ContainsKey(chosen_id) == false)
                    {
                        Console.WriteLine("id is not in the list");
                        return;
                    }
                    book = sameNameDict[chosen_id];
                }
            }
            else if (choice == "id")
            {
                Console.WriteLine("Please enter the book's id");
                string book_id = Console.ReadLine();
                book = findBook(book_id);
                if (book == null)
                {
                    Console.WriteLine("The book doesn't exist");
                    return;
                }
            }
            else
            {
                Console.WriteLine("wrong input");
                return;
            }

            Subscriber sub = findSubscriber(sub_id);
            if (sub == null)
            {
                Console.WriteLine("The subscriber doesn't exist");
                return;
            }

            if (sub.avilableBookToLoan() == false)
            {
                Console.WriteLine("The subscriber got the limit and the maximum loaned books");
                return;
            }

            if (book is DigitalBook)
            {
                sub.addLoanBook(book);
                Console.WriteLine("Success");
                return;
            }

            if (book is PaperBook)
            {
                PaperBook pBook = book as PaperBook;
                if (pBook.avilablePaperBook() == false)
                {
                    Console.WriteLine("there are no available copies");
                    return;
                }
                sub.addLoanBook(book);
                pBook.addCopy();
                Console.WriteLine("Success");
            }
        }

        public void returnBook()
        {
            Console.WriteLine("Please enter the id of the loaner:");
            string sub_id = Console.ReadLine();

            Console.WriteLine("Please enter the book's id:");
            string book_id = Console.ReadLine();

            Subscriber sub = findSubscriber(sub_id);
            if (sub == null)
            {
                Console.WriteLine("The subscriber doesn't exist");
                return;
            }

            Book book = findBook(book_id);
            if (book == null)
            {
                Console.WriteLine("The book doesn't exist");
                return;
            }

            if (!sub.isBookInSubscriber(book))
            {
                Console.WriteLine("the subscriber does not have the book");
                return;
            }

            if (book is DigitalBook)
            {
                sub.returnBookFromLoan(book);
                Console.WriteLine("Success");
                return;
            }

            sub.returnBookFromLoan(book);
            PaperBook book1 = book as PaperBook;
            book1.removeCopy();
            Console.WriteLine("Success");
        }

        public void printBookDetails()
        {
            Console.WriteLine("Please enter the book's title:");
            string title = Console.ReadLine();
            string pattern = "^" + title;
            // Create a Regex
            Regex rg = new Regex(pattern);
            // return all words that match
            foreach (KeyValuePair<string, Book> id_and_book in _booksDict)
            {
                if (rg.Matches(id_and_book.Value.getTitle()).Count > 0)
                {
                    Console.WriteLine(id_and_book.Value.ToString());
                }
            }
        }

        public void printBookGenre()
        {
            Console.WriteLine("Please enter the genre of the book:");
            string genre = Console.ReadLine();
            string genreSum = "";

            foreach (KeyValuePair<string, Book> id_and_book in _booksDict)
            {
                if (id_and_book.Value.getGenre() == genre)
                {
                    genreSum += id_and_book.Value.ToString();
                }
            }
            Console.WriteLine("All the books of" + genre + "genre");
            Console.WriteLine(genreSum);
        }

        public void showSubBooks()
        {
            Console.WriteLine("please enter id:");
            string sub_id = Console.ReadLine();

            Subscriber sub = findSubscriber(sub_id);
            if (sub != null)
            {
                sub.printBookDetails();
                return;
            }
            Console.WriteLine("subcscriber does not exist");
        }
    }


}


